---
title: "Kinematic Data Analysis for Post-Stroke Patients Following Bilateral Versus Unilateral Rehabilitation With an Upper Limb Wearable Robotic System"
thread: B3
lens: M4
relevance: "高"
year: 2012
doi: "10.1109/tnsre.2012.2207462"
arxiv_id: ""
evidence_grade: "A（≥2 个独立来源确认标题）"
confirm_sources: "crossref_doi, europepmc_doi"
---

# Kinematic Data Analysis for Post-Stroke Patients Following Bilateral Versus Unilateral Rehabilitation With an Upper Limb Wearable Robotic System

> ⚠️ **本文件是摘要级定位卡，不是全文翻译。**
> 全部判断仅基于标题、摘要与官方元数据。**引用任何数值、方法细节或结论前，必须回原文核对。**
> 未获取原文者，该条只能作为「线索」使用，不得写入论文结论。

| 项 | 内容 |
|---|---|
| 年份 | 2012 |
| 期刊/会议 | IEEE Transactions on Neural Systems and Rehabilitation Engineering |
| DOI | `10.1109/tnsre.2012.2207462` |
| arXiv | — |
| 线程 | B3 上肢康复_代偿与临床评估 |
| 证据范式 | M4 临床与康复（代偿、功能评定、上肢康复工程） |
| 相关度 | 高（人工裁定） |
| 证据等级 | A（≥2 个独立来源确认标题） |
| 交叉证实来源 | crossref_doi, europepmc_doi |
| 官方 OA | 否 |
| 入口链接 | [https://doi.org/10.1109/tnsre.2012.2207462](https://doi.org/10.1109/tnsre.2012.2207462) |

## 摘要（来源原文，未翻译）

Robot-assisted stroke rehabilitation has become popular as one approach to helping patients recover function post-stroke. Robotic rehabilitation requires four important elements to match the robot to the patient: realistic biomechanical robotic elements, an assistive control scheme enabled through the human-robot interface, a task oriented rehabilitation program based on the principles of plasticity, and objective assessment tools to monitor change. This paper reports on a randomized clinical trial utilizing a complete robot-assisted rehabilitation system for the recovery of upper limb function in patients post-stroke. In this study, a seven degree-of-freedom (DOF) upper limb exoskeleton robot (UL-EXO7) is applied in a rehabilitation clinical trial for patients stable post-stroke (greater than six months). Patients had a Fugl-Meyer Score between 16-39, were mentally alert (> 19 on the VA Mini Mental Status Exam) and were between 27 and 70 years of age. Patients were randomly assigned to three groups: bilateral robotic training, unilateral robotic training, and usual care. This study is concerned with the changes in kinematics in the two robotic groups. Both patient groups played eight therapeutic video games over 12 sessions (90 min, two times a week). In each session, patients intensively played the different combination of video games that directly interacted with UL-EXO7 under the supervision of research assistant. At each session, all of the joint angle data was recorded for the evaluation of therapeutic effects. A new assessment metric is reported along with conventional metrics. The experimental result shows that both groups of patients showed consistent improvement with respect to the proposed and conventional metrics.

## 为什么收录（人工裁定理由）

双侧训练后卒中患者的运动学数据分析（TNSRE，133 引）
