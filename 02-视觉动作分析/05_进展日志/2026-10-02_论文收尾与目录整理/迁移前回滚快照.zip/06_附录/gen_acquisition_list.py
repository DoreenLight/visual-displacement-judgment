#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_acquisition_list.py — 生成**全项目唯一的**待取件总清单。

产物：06_附录/待下载论文总清单.md

## 为什么要有这个脚本（2026-10-03）

合并前项目里有 **5 份**待下载类清单，它们**互相重叠又各自过时**：

| 原文件 | 生成者 | 合并前状态 |
|---|---|---|
| `06_附录/待下载论文总清单.md` | 手工维护 | 🚨 **严重过时**（仍写语料三 106 条 / 已取得 52，实际已 111 条 / 93） |
| `06_附录/需你下载的论文清单.md` | `决策模型工具/gen_download_list.py` | 🚨 过时（语料三 71/29，取件前多为 10-01 状态） |
| `01_参考论文/生物力学线/需人工取件清单.md` | `build_biomech.py` | ✅ 最新 |
| `01_参考论文/Transformer_发展线/需人工取件清单.md` | `build_index.py` | ⚠️ 15 条其实**不是语料条目**（见 §6） |
| `01_参考论文/决策模型线_JEV/需人工取件清单.md` | `build_jev.py` | ✅ 较新 |

**教训**：同一诉求有 5 处副本时，没有任何一处能保证是最新的 ——
所以本脚本**只从数据源重生成，不从任何一份旧清单拷贝**。
人工判断（P0 优先级、实测拦截点）单独放 `取件清单_人工标注.json`，
**凡该文件没有的字段一律不生成**（不猜、不补写）。

## 单一真相来源

- 语料三的「已入库 / OA 被拦 / 非 OA」判定 **import `build_biomech.disk_status`**，
  与 `build_biomech.py` 用的是**同一个函数**（K-numbers 同族：两份判定逻辑必然漂移）。
- 语料二取自 `Transformer_发展线/index.json` 的 `pdf_status`。
- 语料四取自 `决策模型线_JEV/index.json` 的 `pdf_status`，
  **再叠一层全库 DOI 核对**（`library_doi_index()`）：JEV 只核自己的目录，
  漏掉「全文已在语料三」的情况 → 合并后仍会让人重复下载盘上已有的 PDF。
- 语料一按自检 Case 7 的同一判据现算（PDF 无 `_全文翻译.md` 孪生即缺件）。

用法：`python3 06_附录/gen_acquisition_list.py`
"""
import importlib.util
import json
import re
import sys
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / '待下载论文总清单.md'
OVERLAY = HERE / '取件清单_人工标注.json'

TF_ROOT = ROOT / '01_参考论文' / 'Transformer_发展线'
BM_ROOT = ROOT / '01_参考论文' / '生物力学线'
JV_ROOT = ROOT / '01_参考论文' / '决策模型线_JEV'
TOOLS = HERE / 'Transformer语料工具'

# 语料二三的工具脚本不在 06_附录 顶层，用显式路径加载
_spec = importlib.util.spec_from_file_location('B', TOOLS / 'build_biomech.py')
B = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(B)


def load(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding='utf-8'))
    except Exception:                                    # noqa: BLE001
        return default if default is not None else {}


def md(s):
    return (s or '').replace('|', '\\|').replace('\n', ' ')


# ---------------------------------------------------------------- 语料一（现算）
def corpus_one():
    """语料一 = PAPER_ROOTS 下**不属于**语料二/三/四的那部分。

    🚨 口径纪律：这里的判据必须与 `verify_kb.sh` Case 7 的 `pdfs` **完全一致** ——
    它的 `PAPER_ROOTS = [01_参考论文, 09_章隆彬_合作团队]`，**含 09 线**。
    只扫 `01_参考论文` 会少算 09 线的 13 篇（29 vs 42），
    这正是「计数口径由 verify_kb.sh 定义，不得自定 glob」要防的事。
    """
    PAPER_ROOTS = [ROOT / '01_参考论文', ROOT / '09_章隆彬_合作团队']
    EXCLUDE_PARTS = {'.pi', '_translation_outputs', 'libs', 'node_modules',
                     '__pycache__', '.git', '_research_run'}
    bad, n_pdf = [], 0
    for root in PAPER_ROOTS:
        if not root.exists():
            continue
        for p in root.rglob('*.pdf'):
            s = str(p)
            if any(x in s for x in ('Transformer_发展线', '生物力学线', '决策模型线_JEV')):
                continue
            rel = p.relative_to(ROOT)
            if any(part in EXCLUDE_PARTS for part in rel.parts):
                continue
            if any(part.startswith('_backup') for part in rel.parts):
                continue
            n_pdf += 1
            if not p.with_name(p.stem + '_全文翻译.md').exists():
                bad.append(p)
    return n_pdf, bad


# ---------------------------------------------------------------- 语料二
def corpus_two():
    idx = load(TF_ROOT / 'index.json', {'papers': []})
    need = [p for p in idx.get('papers', []) if p.get('pdf_status') != 'ok']
    # 「检索未命中」来自建语料时的候选池，**不是待下载条目**（它们根本没进语料）
    res = load(TOOLS / 'corpus_resolved.json', {'papers': []})
    unres = [p for p in res.get('papers', [])
             if p.get('status') not in ('confirmed', 'confirmed_single')]
    return idx.get('papers', []), need, unres


# ---------------------------------------------------------------- 语料三
def corpus_three():
    res = load(TOOLS / 'biomech_resolved.json', {'papers': []})
    cand = load(TOOLS / 'biomech_candidates.json', {'meta': {'axes': {'thread': {}}}})
    labels = cand['meta']['axes']['thread']
    rep = load(TOOLS / 'biomech_download_report.json', {'items': []})
    dl = {it['key']: it for it in rep.get('items', []) if it.get('key')}

    usable = [p for p in res.get('papers', [])
              if p.get('status') in ('confirmed', 'confirmed_single')]
    got, blocked, not_oa, vanished = [], [], [], []
    for p in usable:
        s, ref = B.disk_status(p, dl, labels)        # ← 与 build_biomech 共用同一判定
        (got if s == 'ok' else vanished if s == 'ok_but_missing'
         else blocked if s == 'blocked' else not_oa).append((p, ref))
    n_pdf = sum(1 for _, r in got if r.endswith('.pdf'))
    n_xml = len(got) - n_pdf
    return got, blocked, not_oa, vanished, n_pdf, n_xml


def library_doi_index():
    """全库 DOI → 落盘路径，**跨语料**。

    为什么需要：语料四 `index.json` 的 `pdf_status` 只看它自己的目录，
    于是 `10.1109/tbme.2008.2005946`（A Real-Time, 3-D Musculoskeletal Model）
    在 JEV 侧记为「未入库 → 可取」，而全文其实早已躺在
    `生物力学线/B2_肌肉骨骼动力学_与可微仿真/` 里。
    不做跨语料核对，就会**让用户去下一份已经在盘上的 PDF** ——
    这正是「五份清单并存」要消灭的那类错误，不能在合并后还留着。
    """
    res = load(TOOLS / 'biomech_resolved.json', {'papers': []})
    cand = load(TOOLS / 'biomech_candidates.json', {'meta': {'axes': {'thread': {}}}})
    rep = load(TOOLS / 'biomech_download_report.json', {'items': []})
    dl = {it['key']: it for it in rep.get('items', []) if it.get('key')}
    labels = cand['meta']['axes']['thread']
    out = {}
    for p in res.get('papers', []):
        if p.get('status') not in ('confirmed', 'confirmed_single'):
            continue
        s, ref = B.disk_status(p, dl, labels)
        if s == 'ok' and p.get('doi'):
            out.setdefault(p['doi'].lower(), ref)
    return out


# ---------------------------------------------------------------- 语料四
def corpus_four():
    """语料四未入库条目分**三档**，不是两档。

    🚨 两档分类会**把可取的论文藏进「网页型」**：首版用「无 DOI 且无 arXiv → 网页型」，
    结果 PMC5469353（有开放全文）与 Zenodo 那条被误标成「没有 PDF 可下」，
    等于**把能下的论文从待办里抹掉**。故按「**有没有可取全文**」而非「有没有标识」分档：

      3.1 有 DOI/arXiv 标识但未入库      → 可取，按标识去
      3.2 无标识但链接指向可取全文        → **先补标识**再入库（PMC/Zenodo/openaccess/doi.org）
      3.3 网页型证据，真没有可取 PDF      → 厂商文档 / 社区报告 / 编者判断 / 黑盒探测
    """
    idx = load(JV_ROOT / 'index.json', {'papers': []})
    ps = idx.get('papers', [])
    xlib = library_doi_index()
    def has_fulltext(p):
        ref = p.get('fulltext_path') or p.get('fulltext_reference')
        if not ref:
            local = xlib.get((p.get('doi') or '').lower())
            ref = '01_参考论文/生物力学线/' + local if local else ''
        return bool(ref and (ROOT / ref).is_file())
    need = [p for p in ps if p.get('pdf_status') != 'ok' and not has_fulltext(p)]
    WEB_EVIDENCE = {'编者判断', '黑盒探测', '厂商自述', '社区报告'}
    RETRIEVABLE = re.compile(r'(pmc\.ncbi|pubmed|zenodo|openaccess|doi\.org/|arxiv\.org)', re.I)
    ident, noident_oa, web = [], [], []
    for p in need:
        ev = (p.get('evidence') or '').strip()
        url = p.get('url_abs') or ''
        if p.get('doi') or p.get('arxiv_id'):
            ident.append(p)
        elif ev in WEB_EVIDENCE or not RETRIEVABLE.search(url):
            web.append(p)
        else:
            # 无标识但链接指向 PMC / Zenodo / openaccess 等**有全文可取**的位置
            noident_oa.append(p)
    return ps, need, ident, noident_oa, web


def main():
    ov = load(OVERLAY)
    p0_by_doi = {e['doi'].lower(): e for e in ov.get('P0', [])}
    gate = ov.get('实测拦截点', {})

    n1, bad1 = corpus_one()
    tf_all, tf_need, tf_unres = corpus_two()
    bm_got, bm_blocked, bm_notoa, bm_van, bm_pdf, bm_xml = corpus_three()
    jv_all, jv_need, jv_ident, jv_noident, jv_web = corpus_four()

    # 跨语料已在库核对（§0 与 §3 共用，故在此算一次）
    XLIB = library_doi_index()
    jv_xlib = [p for p in jv_all if p.get('fulltext_reference')
               and (ROOT / p['fulltext_reference']).is_file()]

    # P0 状态：**由磁盘实况推导**，不抄旧清单。
    # 旧总清单把 P0-1～P0-6 全标成「需订阅 / 本轮补入」，但它们其实早已入库
    # —— 那是手工清单没跟上的过时状态。状态列必须现算。
    _res = load(TOOLS / 'biomech_resolved.json', {'papers': []})
    _cand = load(TOOLS / 'biomech_candidates.json', {'meta': {'axes': {'thread': {}}}})
    _rep = load(TOOLS / 'biomech_download_report.json', {'items': []})
    _dl = {it['key']: it for it in _rep.get('items', []) if it.get('key')}
    _by_doi = {(p.get('doi') or '').lower(): p for p in _res.get('papers', []) if p.get('doi')}

    def p0_state(doi):
        p = _by_doi.get(doi.lower())
        if p is None:
            return '🚨 不在语料三索引', '—'
        s, ref = B.disk_status(p, _dl, _cand['meta']['axes']['thread'])
        if s == 'ok':
            ext = 'XML' if ref.endswith('.xml') else 'PDF'
            return '✅ **已入库**', ref
        if s == 'blocked':
            return '⚠️ OA 被拦，需浏览器', ref or '—'
        if s == 'not_oa':
            return '❌ 需订阅', '—'
        if s == 'ok_but_missing':
            return '🚨 报告称已下载但磁盘没有', '—'
        return '⬜ 未取', '—'

    def p0tag(item):
        d = (item.get('doi') or '').lower()
        e = p0_by_doi.get(d)
        return (' ⭐**%s**' % e['id']) if e else ''

    L = []
    L += ['# 待下载论文总清单 — 全项目（**唯一取件入口**）', '',
          '> **本文件由 `06_附录/gen_acquisition_list.py` 生成，请勿手工编辑。**',
          '> 数据源：四语料 `index.json` / `biomech_resolved.json` / 下载报告 / **磁盘实况**。',
          '> 人工判断（P0 优先级、实测拦截点）在 [`取件清单_人工标注.json`](取件清单_人工标注.json)。',
          '> 生成日期：%s ｜ 计数由脚本实测，不手写。' % date.today().isoformat(), '',
          '> 📌 **2026-10-03 合并**：本清单此前有 **5 份**分散副本（2 份在 `06_附录`、3 份在各自语料目录），',
          '> 互相重叠且各自过时（手工总清单一度仍写「语料三 106 条 / 已取得 52」，实际已是 111 条 / 93）。',
          '> 现全部并入本文件，其余 4 份停止生成。', '',
          '---', '']

    # ---------------- 0 概览 ----------------
    L += ['## 0. 一分钟看结论', '',
          '| 语料 | 已入库 | 待取件 / 非 PDF 证据 | 说明 |', '|---|---|---|---|',
          '| **语料一**（主语料） | %d | %d | %s |' % (
              n1, len(bad1), '✅ 无缺口' if not bad1 else '⚠️ 见 §2.0'),
          '| **语料二**（Transformer 发展线） | %d | %d | %s |' % (
              len(tf_all) - len(tf_need), len(tf_need),
              '✅ 全部有 PDF + 定位卡' if not tf_need else '⚠️ 见 §4'),
          '| **语料三**（生物力学与上肢运动学） | %d | %d | ⚠️ 仍有论文全文缺口 |' % (
              len(bm_got), len(bm_blocked) + len(bm_notoa)),
          '| **语料四**（决策模型线 / JEV） | %d | %d | 三档：有标识 %d / 无标识可取 %d / 网页型 %d |' % (
              len(jv_all) - len(jv_need), len(jv_need),
              len(jv_ident), len(jv_noident), len(jv_web)),
          '',
          '**语料三全文口径拆分**：PDF **%d**（三重校验通过）+ Europe PMC JATS XML **%d**'
          '（开放全文，**非翻译**）= **%d**。' % (bm_pdf, bm_xml, len(bm_got)),
          '']
    versions = [(p, ref) for p, ref in bm_got if p.get('fulltext_version')]
    if versions:
        L += ['> ⚠️ 已入库数包含作者稿或技术报告，**不等于全部取得期刊正式排版版**。', '',
              '| 已取得的版本 | 论文 | 核查说明 |', '|---|---|---|']
        for p, ref in versions:
            L.append('| %s | %s | %s |' % (md(p['fulltext_version']), md(p.get('title')),
                     md(p.get('acquisition_check') or p.get('note'))))
        L += ['']
    if jv_xlib:
        L += ['> 📚 **语料四有 %d 条引用既有全文**，已计入入库数、未计入待取件数。'
              '**不要重复下载** —— 详见 §3 开头。' % len(jv_xlib), '']
    if bad1:
        L += ['### 2.0 语料一 · 缺全文翻译（%d 篇）' % len(bad1), '',
              '| # | 相对路径 |', '|---|---|']
        L += ['| %d | `%s` |' % (i, p.relative_to(ROOT)) for i, p in enumerate(bad1, 1)]
        L += ['']

    # ---------------- 1 P0 ----------------
    L += ['---', '',
          '## 1. 🔴 P0 必取（%d 篇 · 人工裁定优先级）' % len(ov.get('P0', [])), '',
          '> 📌 **为什么单列 P0**：下面 §3/§4 是按**取件难度**分的，两组的排序里',
          '> **没有「这篇对论文的价值」**。P0 是按「**哪几篇决定我们还能主张什么**」排的。',
          '> 判据是人工裁定，不是脚本可得 —— 故存于 `取件清单_人工标注.json`。', '',
          '| # | 论文题名 | 出处 | 地址 | 为什么是 P0 | 状态（磁盘实况） |',
          '|---|---|---|---|---|---|']
    for e in ov.get('P0', []):
        st, _ = p0_state(e['doi'])
        L.append('| **%s** | %s | %s | https://doi.org/%s | %s | %s |' % (
            e['id'], md(e['题名']), md(e['出处']), e['doi'], md(e['为什么是P0']), st))
    L += ['']
    n_in = sum(1 for e in ov.get('P0', []) if p0_state(e['doi'])[0].startswith('✅'))
    L += ['> **状态由磁盘实况现算**（`build_biomech.disk_status`），不抄旧清单 ——',
          '> 旧版手工总清单曾把 P0-1～P0-6 全标成「需订阅 / 本轮补入」，',
          '> 当前 P0 全组 **%d 篇已入库**，只有 **%d 篇仍未取**。'
          % (n_in, len(ov.get('P0', [])) - n_in), '']
    for e in ov.get('P0', []):
        bits = []
        if e.get('取回后要做'):
            bits.append('**取回后要做**：%s' % e['取回后要做'])
        if e.get('限制'):
            label = '取件前历史标注（已取得原文，正文分析仍待完成）' if p0_state(e['doi'])[0].startswith('✅') else '限制'
            bits.append('**%s**：%s' % (label, e['限制']))
        if e.get('注意'):
            bits.append('**注意**：%s' % e['注意'])
        if bits:
            L += ['> **%s**（`%s`）' % (e['id'], e['doi']), '> ' + ' ｜ '.join(bits), '']
    acts = ov.get('P0取回后要做的五件事', [])
    if acts:
        L += ['### P0 全部取回后要做的五件事（别只下就完事）', '']
        L += ['%d. %s' % (i, a) for i, a in enumerate(acts, 1)]
        L += ['']

    # ---------------- 2 语料三 ----------------
    L += ['---', '',
          '## 2. 语料三（生物力学与上肢运动学）· 需取件 %d 篇'
          % (len(bm_blocked) + len(bm_notoa)), '',
          '> 取件纪律：**优先官方、作者或机构来源；按用户授权可扩展渠道检索，'
          '但不规避账号权限、付费墙或反爬验证。候选全文须核验论文身份，失败抓取不计入库。**', '']
    L += ['### 2.1 OA 但被出版商拦截（%d 篇）· 浏览器人工下载' % len(bm_blocked), '',
          '> Unpaywall 确认有官方 OA 直链，但出版商返回反爬验证页。',
          '> 「实测拦截点」一栏是**用真实 Chrome 逐篇试出来的**；未试过的标「未实测」，不猜。', '',
          '| # | 论文 | 年 | 期刊/会议 | DOI | 线程 | OA 直链 | 实测拦截点 |',
          '|---|---|---|---|---|---|---|---|']
    for i, (p, url) in enumerate(bm_blocked, 1):
        d = (p.get('doi') or '').lower()
        L.append('| %d | %s%s | %s | %s | `%s` | %s | [取件](%s) | %s |' % (
            i, md(p.get('title')), p0tag(p), p.get('year') or '—',
            md(p.get('venue')) or '—', d, p.get('thread') or '—', url,
            gate.get(d, '未实测')))
    L += ['']
    L += ['### 2.2 非 OA，需机构订阅（%d 篇）' % len(bm_notoa), '',
          '| # | 论文 | 年 | 期刊/会议 | DOI | 线程 | 证据等级 |',
          '|---|---|---|---|---|---|---|']
    for i, (p, _) in enumerate(bm_notoa, 1):
        L.append('| %d | %s%s | %s | %s | `%s` | %s | %s |' % (
            i, md(p.get('title')), p0tag(p), p.get('year') or '—',
            md(p.get('venue')) or '—', (p.get('doi') or '').lower(),
            p.get('thread') or '—', (p.get('evidence_grade') or '—')[:1]))
    L += ['']
    if bm_van:
        L += ['> 🚨 **报告称已下载但磁盘没有：%d 篇** —— 这类条目不计入「已入库」，'
              '也不要从清单里删：' % len(bm_van)]
        L += ['> ' + '、'.join('`%s`' % md(p.get('title'))[:40] for p, _ in bm_van)]
        L += ['']

    # ---------------- 3 语料四 ----------------
    # 跨语料已在库核对（XLIB/jv_xlib 已在 main() 开头算好）：
    # `index.json` 的 pdf_status 只看 JEV 自己的目录，
    # 漏掉「全文其实在语料三」的情况 → 会让人去下一份盘上已有的 PDF。

    def xlib_cell(p):
        d = (p.get('doi') or p.get('arxiv_id') or '').lower()
        ref = p.get('fulltext_path') or p.get('fulltext_reference')
        if not ref and XLIB.get(d):
            ref = '01_参考论文/生物力学线/' + XLIB[d]
        return '📚 **全文已在库**（`%s`）' % ref if ref and (ROOT / ref).is_file() else '⬜ 确实没有'

    L += ['---', '',
          '## 3. 语料四（决策模型线 / JEV）· 待论文全文 %d 条 / 非 PDF 证据 %d 条' % (len(jv_ident) + len(jv_noident), len(jv_web)), '']
    if jv_xlib:
        L += ['> 📚 以下 %d 条**全文已在库**，通过原件引用复用，**不属于待取件**。'
              '**别去重复下载**，直接使用下列原件路径。' % len(jv_xlib), '',
              '| 题名 | 全库实况 |', '|---|---|']
        for p in jv_xlib:
            L.append('| %s | %s |' % (md(p.get('title')), xlib_cell(p)))
        L += ['']
    L += ['### 3.1 有 DOI/arXiv 标识但全文尚未入库（%d 条）· 待获取' % len(jv_ident), '',
          '> 有标识不代表存在开放全文；订阅、验证码和元数据订正按实测记录处理。', '',
          '| # | 题名 | 出处 | 链接 | 证据等级 | 全库实况 | 本次核查 |', '|---|---|---|---|---|---|---|']
    for i, p in enumerate(jv_ident, 1):
        L.append('| %d | %s | %s | %s | %s | %s | %s |' % (
            i, md(p.get('title')), md(p.get('venue')) or '—',
            p.get('url_abs') or '—', md(p.get('evidence_grade')) or '—',
            xlib_cell(p), md(p.get('acquisition_check')) or '未记录'))
    L += ['']
    L += ['### 3.2 ⚠️ 无标识但链接指向可取全文（%d 条）· 先补标识' % len(jv_noident), '',
          '> 这些**有可取全文**，只是 `index.json` 里**缺 DOI/arXiv 标识** ——',
          '> 首版两档分类把它们误标成「网页型、无 PDF 可下」，**等于把能下的论文从待办里抹掉**。',
          '> 取回后须补标识，否则它们永远进不了可引用索引。', '',
          '| # | 题名 | 可取链接 | 证据等级 | 全库实况 |', '|---|---|---|---|---|']
    for i, p in enumerate(jv_noident, 1):
        L.append('| %d | %s | %s | %s | %s |' % (
            i, md(p.get('title')), p.get('url_abs') or '—',
            md(p.get('evidence')) or '—', xlib_cell(p)))
    L += ['']
    L += ['### 3.3 网页型证据与编者分析 —— 不是缺失论文 PDF（%d 条）' % len(jv_web), '',
          '> 这些**不是传闻，但也没有 PDF**。它们是厂商文档、社区实测报告、黑盒探测记录。',
          '> 「没有 PDF」不是「不可信」，但**也不能当同行评审论文引用**。', '',
          '| # | 题名 | 载体 | 链接 | 类型 | 核查 / 既有证据 |', '|---|---|---|---|---|---|' ]
    for i, p in enumerate(jv_web, 1):
        L.append('| %d | %s | %s | %s | %s | %s |' % (
            i, md(p.get('title')), md(p.get('venue')) or '—',
            p.get('url_abs') or '—', md(p.get('evidence')) or '—',
            md(p.get('acquisition_check')) or '尚未记录'))
    L += ['',
          '> 📌 **但不能因为没有 PDF 就当作传闻** —— 恰恰相反，JEV 至今没有一篇厂商撰写的架构论文，',
          '> 这个「事实缺失」本身就是本语料的核心发现之一。', '']

    # ---------------- 4 语料二 ----------------
    L += ['---', '',
          '## 4. 语料二（Transformer 发展线）· 需取件 %d 篇' % len(tf_need), '']
    if tf_need:
        L += ['| # | 论文 | 年 | arXiv ID | 失败原因 |', '|---|---|---|---|---|']
        for i, p in enumerate(tf_need, 1):
            L.append('| %d | %s | %s | `%s` | 缺 PDF |' % (
                i, md(p.get('title')), p.get('published') or '—', p.get('arxiv_id') or '—'))
        L += ['']
    else:
        L += ['✅ **无缺口** —— %d 篇全部 `pdf_status=ok`，PDF 与定位卡齐备。' % len(tf_all), '']
    L += ['### 4.1 建语料时的检索未命中（%d 条）—— 🚫 **这不是待下载清单**' % len(tf_unres), '',
          '> ⚠️ **口径纠偏（2026-10-03）**：这 %d 条**根本不是语料条目** —— 它们是建语料时'
          '写进候选池的**预期标题**，arXiv 多次检索未命中，因此**从未被收编**。' % len(tf_unres),
          '> 旧清单把它们放在「需人工取件清单」标题下，**会被误读成「这些论文还没下」**。',
          '> 实测：语料二索引 %d 篇全部 `pdf_status=ok`，且这 %d 条的标题在索引中一条都匹配不上。' % (
              len(tf_all), len(tf_unres)),
          '> 它们的价值是**检索穷尽性留证**（说明「arXiv 上确实找不到」），故保留在此节。', '']
    if tf_unres:
        L += ['| # | 编制时的预期标题 | 状态 | 相似度 | 检索命中情况 |',
              '|---|---|---|---|---|']
        for i, p in enumerate(tf_unres, 1):
            cands = ' ｜ '.join('%s：%s' % (c['arxiv_id'], c['title'][:46])
                                for c in (p.get('candidates') or [])[:2]) or '无命中'
            try:
                sc = '%.2f' % float(p.get('match_score') or 0)
            except (TypeError, ValueError):
                sc = str(p.get('match_score') or '—')
            L.append('| %d | %s | `%s` | %s | %s |' % (
                i, md(p.get('title')), p.get('status'), sc, md(cands)))
        L += ['']

    # ---------------- 5 浏览器取件 ----------------
    L += ['---', '', '## 5. 浏览器取件：能做什么、不能做什么', '']
    L += ov.get('拦截类型实测汇总', [])
    L += ['', '> **我没有做也不会做的事**：破解 reCAPTCHA / Radware 验证码、伪造浏览器指纹绕过 WAF、批量下载器。',
          '> 这些是出版商明示的访问控制，绕过去等于侵权。', '',
          '> **但这不影响你**：OA 组全部免费，你用普通浏览器打开就会看到正常的验证码/验证页面，',
          '> 点一下或等几秒就能下 —— **你不是在绕过，你就是正常用户**。', '',
          '> 通用手法：%s' % ov.get('浏览器取件通用手法', ''), '']
    rec = ov.get('本库自行取回记录', [])
    if rec:
        L += ['### 5.1 本库自行取回（你不用管）', ''] + rec + ['']

    # ---------------- 6 归位与重跑 ----------------
    L += ['---', '', '## 6. 取回后放哪里', '',
          '### 6.1 语料三（按线程归位）', '',
          '| 线程 | 目录 |', '|---|---|',
          '| `B1` | `01_参考论文/生物力学线/B1_视觉运动学_估计与验证方法学/` |',
          '| `B2` | `01_参考论文/生物力学线/B2_肌肉骨骼动力学_与可微仿真/` |',
          '| `B3` | `01_参考论文/生物力学线/B3_上肢康复_代偿与临床评估/` |',
          '| `B4` | `01_参考论文/生物力学线/B4_离散运动学token_与表征量化/` |',
          '| `B5` | `01_参考论文/生物力学线/B5_视觉运动学到动力学_桥接/` |', '',
          '### 6.2 语料四', '',
          '- `01_参考论文/决策模型线_JEV/D4_AAN辅助控制与介入决策/`（介入决策主线）',
          '- `01_参考论文/决策模型线_JEV/D5_轻量化非Transformer路线/`（工程基线）', '',
          '### 6.3 🚨 文件名必须与定位卡同名', '',
          '语料三的 PDF 名须等于 `<题名>_Abstract_Card.md` 去掉后缀，清洗规则为',
          '「非法字符 `\\/:*?"<>|` 替换成 `_`，再截断 **%d** 字符」' % B.NAME_MAXLEN,
          '（`build_biomech.py` 的 `safe_name(title_of(p), NAME_MAXLEN)`）——',
          '**自检 Case 7 靠这个配对 PDF 与卡片，改名字会 FAIL。**', '',
          '### 6.4 放好后重跑', '', '```bash',
          'python3 06_附录/Transformer语料工具/build_biomech.py   # 语料三 index.json / LIST.md / 定位卡',
          'python3 06_附录/Transformer语料工具/build_index.py     # 语料二 index.json / LIST.md',
          'python3 06_附录/决策模型工具/build_jev.py              # 语料四 index.json / LIST.md',
          'python3 06_附录/gen_acquisition_list.py               # ← 本清单',
          'bash    06_附录/自检脚本/verify_kb.sh                 # 21 个用例',
          '```', '']

    # ---------------- 7 边界 ----------------
    L += ['---', '', '## 7. 边界声明', '']
    for b in ov.get('边界声明', []):
        L.append('- %s' % b)
    L += ['']

    OUT.write_text('\n'.join(L), encoding='utf-8')
    print('已生成：%s' % OUT)
    print('  语料一 已入库 %d ｜缺件 %d' % (n1, len(bad1)))
    print('  语料二 已入库 %d ｜缺件 %d ｜检索未命中(非待下载) %d'
          % (len(tf_all) - len(tf_need), len(tf_need), len(tf_unres)))
    print('  语料三 已入库 %d (PDF %d + XML %d) ｜OA被拦 %d ｜非OA %d'
          % (len(bm_got), bm_pdf, bm_xml, len(bm_blocked), len(bm_notoa)))
    print('  语料四 已入库 %d ｜待论文全文 %d (有标识 %d + 无标识可取 %d) ｜非PDF证据 %d'
          % (len(jv_all) - len(jv_need), len(jv_ident) + len(jv_noident),
             len(jv_ident), len(jv_noident), len(jv_web)))
    print('  P0 组 %d 篇' % len(ov.get('P0', [])))


if __name__ == '__main__':
    sys.exit(main())
